<?php defined('SYSPATH') OR die('No direct script access.');

class Session_Cookie extends Kohana_Session_Cookie {}
