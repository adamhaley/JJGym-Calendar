<?php defined('SYSPATH') OR die('No direct script access.');

class Kohana_HTTP_Exception_409 extends HTTP_Exception {

	/**
	 * @var   integer    HTTP 409 Conflict
	 */
	protected $_code = 409;

}
