<?php defined('SYSPATH') OR die('No direct script access.');

class HTTP_Exception_303 extends Kohana_HTTP_Exception_303 {}
