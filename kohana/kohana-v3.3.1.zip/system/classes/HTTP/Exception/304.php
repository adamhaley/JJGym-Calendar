<?php defined('SYSPATH') OR die('No direct script access.');

class HTTP_Exception_304 extends Kohana_HTTP_Exception_304 {}
