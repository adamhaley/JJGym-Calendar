<?php defined('SYSPATH') OR die('No direct script access.');

class Profiler extends Kohana_Profiler {}
