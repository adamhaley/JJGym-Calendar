<?php defined('SYSPATH') or die('No direct script access.');

class Minion_Exception extends Kohana_Minion_Exception {}
