Minion is a cli tool for performing tasks

Usage 

    <?php echo $_SERVER['argv'][0]; ?> {task} --task=[options]

Where {task} is one of the following:

<?php foreach($tasks as $task): ?>
  * <?php echo $task; ?>

<?php endforeach; ?>

For more information on what a task does and usage details execute 

    <?php echo $_SERVER['argv'][0]; ?> --task={task} --help

